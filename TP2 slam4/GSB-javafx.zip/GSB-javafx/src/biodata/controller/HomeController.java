package biodata.controller;

public class HomeController {
}
