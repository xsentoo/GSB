package biodata.controller;

public class grafikController {
}
