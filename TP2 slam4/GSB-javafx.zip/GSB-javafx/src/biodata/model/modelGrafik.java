package biodata.model;

public class modelGrafik {
}
