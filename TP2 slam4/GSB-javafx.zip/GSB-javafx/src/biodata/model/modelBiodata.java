package biodata.model;

public class modelBiodata {
}
